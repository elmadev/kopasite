FIX for the problem of "low fps" while playing Elma under WIndows XP.

Type: Loader

--- How to use ---
Extract the files (ElmaXP.exe, Elma12XP.exe) to Elma directory.
To play "fixed" Elma simply run ElmaXP.exe.
If you use Elma1.2 (or 1.2beta), Elma12XP.exe should be run.

--- How it works ---
At my comp - just fine :]
Indeed, the program is max simple - it just tunes system timer,
then runs Elma, and when Elma is finished it tunes the timer back.
All the difference between loaders ElmaXP.exe and Elma12XP.exe is
the file they run (Elma.exe or Elma12.exe respectively).

--- Contacts ---
Nick: nh
Email: nh@gorodok.net
ICQ: 254629369
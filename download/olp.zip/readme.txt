
OLP v1.01 -  Official Level Pack
--------------------------------

The pack consists of 36 new levels for Elasto Mania
Release date: 03/06/2001 
Selection made by: Mate Magyar
You can count your total time with the olptotal.xls file
You can download the latest OLP pack and go to its updated Best time list at http://www.elastomania.com/olp.htm


Level makers:

        LEV.NO. LEVEL NAME        MADE BY

        OLP 01  Drive             Fuida
        OLP 02  Spice Paradise    Abula
        OLP 03  Creeping          Sniper
        OLP 04  Island Jumper     Jatom
        OLP 05  Sikasakitus       Orcc
        OLP 06  Killer Dumping    Bob
        OLP 07  Cosine            Csaba Rozsa
        OLP 08  Brick Bends       Vide
        OLP 09  Rough Flat        Petri
        OLP 10  Himalaya          YeeS
        OLP 11  Climb the Wall    TL
        OLP 12  Trial Motor       Ted Human
        OLP 13  Deserted          Timmo
        OLP 14  Cliffhanger       Fuida
        OLP 15  IQ                MoSH MaN
        OLP 16  Off Road          Timmo
        OLP 17  Tricky Spring     Jakob
        OLP 18  Short Neck        Umiz
        OLP 19  Dunes             Timmo
        OLP 20  Synonymous        Elmaniac
        OLP 21  Mountain Lakes    Mark
        OLP 22  Circulation       Sniper
        OLP 23  Grasshopper       Petri
        OLP 24  Snail             Radi
        OLP 25  Basketball        MUe
        OLP 26  Apple Pile        TL
        OLP 27  Newton            Bartek
        OLP 28  Downhill 2        Petri
        OLP 29  What the Heck 2   MGen
        OLP 30  Effigy            mrickx
        OLP 31  Headbanger Remix  MUe
        OLP 32  Intruder          Psy
        OLP 33  Drop and Hop      Karlis
        OLP 34  Flawless Run	  Zoul
        OLP 35  Psycho Path       Timmo
        OLP 36  Asteroids         LoCa

Thank you guys for all the levels you sent me whether I accepted it or not! MUe
